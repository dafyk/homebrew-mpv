/*
 * Copyright © 2021, VideoLAN and librist authors
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#ifndef LIBRIST_CONFIG_H
#define LIBRIST_CONFIG_H

#define HAVE_MBEDTLS 1

#endif /* LIBRIST_CONFIG_H */
